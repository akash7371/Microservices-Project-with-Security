package com.cg.entity;

public interface Role {
	String user="user";
	String admin="admin";
	//String deliveryAgent="deliveryAgent";
}

package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.dto.Flight;
import com.cg.feign.FlightServiceFeign;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SearchServiceImpl implements SearchService {

	@Autowired(required = true)
	private FlightServiceFeign flightServiceFeign;

	@Override
	public ResponseEntity<List<Flight>> searchFlight(String source, String dest, String dateTime) throws Exception {
		
		log.info("- search-service - Searching for flights from '{}' to '{}' on '{}'", source, dest, dateTime);

		ResponseEntity<List<Flight>> responseEntity = flightServiceFeign.loadBySourceAndDestinationAndDate(source, dest, dateTime);
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            List<Flight> flights = responseEntity.getBody();
            if (flights != null && !flights.isEmpty()) {
                log.info("- search-service - Found {} flights from '{}' to '{}' on '{}'", flights.size(), source, dest, dateTime);
                return ResponseEntity.ok(flights);
            } else {
                log.info("- search-service - No flights found from '{}' to '{}' on '{}'", source, dest, dateTime);
                return ResponseEntity.noContent().build();
            }
        }else {
        	log.error("- search-service - Failed to retrieve flights from '{}' to '{}' on '{}'. Status code: {}", source, dest, dateTime, responseEntity.getStatusCode());
            return ResponseEntity.status(responseEntity.getStatusCode()).body(null);
        }
	}

}

package com.cg.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.dto.Flight;

public interface SearchService {

	ResponseEntity<List<Flight>> searchFlight(String source, String dest, String dateTime) throws Exception;

}

package com.cg.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.Flight;
import com.cg.service.SearchService;

import lombok.extern.slf4j.Slf4j;


@RestController 
@Slf4j
public class SearchController {

	@Autowired
	private SearchService searchService;
	
	@GetMapping("/searchFlight/{source}/{dest}/{dateTime}")
	@PreAuthorize("hasAuthority('user')")
	public ResponseEntity<List<Flight>> searchFlight(@PathVariable String source, @PathVariable String dest, @PathVariable String dateTime) throws Exception{
		
		log.info("- search-service - Request to search flights from {} to {} on {}", source, dest, dateTime);
		
		return searchService.searchFlight(source,dest,dateTime);
		
	}
	
	@GetMapping("/get")
	@PreAuthorize("hasAuthority('user')")
	public String getMessage() {
		return "search-service";
	}
}

package com.cg.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.Profile;


@Repository
public interface UserProfileRepository extends JpaRepository<Profile, String>{

	Optional<Profile> findUserIdByUsername(String username);
	
	Profile findByUsername(String username);

	String deleteByUsername(String username);

}

package com.cg.dto;

import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.Embedded;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Flight {

	@Id
	private int flightId;
	private String source;
	private String destination;
	private LocalDateTime localDateTime;
	private LocalTime departureTime;
	private LocalTime landingTime;
	private double economyRate;
	private double businessRate;
	
	@Embedded
	private Seat seat;
}

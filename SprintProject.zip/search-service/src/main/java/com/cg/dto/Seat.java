package com.cg.dto;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Embeddable
public class Seat {
	
	private int totalSeats;
	private int totalEconomySeats;
	private int totalBussinessSeats;
	private int totalAvailableSeats;
	private int economyAvailable;
	private int bussinessAvailable;
	
}

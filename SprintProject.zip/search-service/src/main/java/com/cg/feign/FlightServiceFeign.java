package com.cg.feign;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.dto.Flight;

@Component
@FeignClient(name = "flight-service")
public interface FlightServiceFeign {

	@GetMapping("/flight/loadBySourceAndDestinationAndDate/{from}/{to}/{date}")
	public ResponseEntity<List<Flight>> loadBySourceAndDestinationAndDate(@PathVariable String from , @PathVariable String to, @PathVariable String date) throws Exception;
		
}

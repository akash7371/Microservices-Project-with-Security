package com.cg;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.cg.controller.SearchController;
import com.cg.dto.Flight;
import com.cg.dto.Seat;
import com.cg.service.SearchService;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class SearchServiceApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SearchService searchService;

	@InjectMocks
	private SearchController searchController;

	@Test
	@WithMockUser(authorities = "user")
	public void testSearchFlightSuccess() throws Exception {
		String source = "NYC";
		String dest = "LAX";
		String dateTime = "2024-09-18T10:00:00";
		List<Flight> flights = Arrays.asList(new Flight(1, source, dest, LocalDateTime.parse(dateTime),
				LocalTime.of(10, 0), LocalTime.of(14, 0), 200.0, 500.0, new Seat()));
		when(searchService.searchFlight(source, dest, dateTime)).thenReturn(ResponseEntity.ok(flights));

		mockMvc.perform(
				get("/searchFlight/" + source + "/" + dest + "/" + dateTime).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	@WithMockUser(authorities = "user")
	public void testSearchFlightFailure() throws Exception {
		String source = "NYC";
		String dest = "LAX";
		String dateTime = "2024-09-18T10:00:00";
		when(searchService.searchFlight(source, dest, dateTime)).thenThrow(new Exception("Internal Server Error"));

		mockMvc.perform(
				get("/searchFlight/" + source + "/" + dest + "/" + dateTime).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isInternalServerError());
	}
}

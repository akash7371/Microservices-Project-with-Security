package com.cg.exception;

public class FlightException extends Exception {

	public FlightException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

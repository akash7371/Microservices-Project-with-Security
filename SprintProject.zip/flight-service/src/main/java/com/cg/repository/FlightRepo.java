package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.entity.Flight;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;


@Repository
public interface FlightRepo extends JpaRepository<Flight, Integer>{
	
	public List<Flight> findBySourceAndDestinationAndLocalDateTime(String from,String to,LocalDateTime date);

}

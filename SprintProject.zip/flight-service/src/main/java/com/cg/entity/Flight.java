package com.cg.entity;

import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Flight {
	@Id
	private int flightId;
	private String source;
	private String destination;
	private LocalDateTime localDateTime;
	private LocalTime departureTime;
	private LocalTime landingTime;
	private double economyRate;
	private double businessRate;
	
	@Embedded
	private Seat seat;
	
}

package com.cg.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.cg.dto.FlightRatesResponse;
import com.cg.dto.SeatBooking;
import com.cg.entity.Flight;
import com.cg.exception.FlightException;

public interface FlightService {

	public String addflight(Flight flight) throws FlightException;
	
	public Flight getFlightById(int flightId) throws FlightException;
	
	public String deleteflight(int flightId) throws FlightException;
	
	public List<Flight> displayall(String from, String to, LocalDateTime date) throws FlightException;
	
	public List<Flight> displayall() throws FlightException;
	
	public String updateSeatDetails(List<SeatBooking> seatList, int id) throws FlightException;

	public Optional<FlightRatesResponse> getFlightRatesById(int flightId) throws FlightException;
	
	public Flight getFlightDateById(int id) throws FlightException;
}

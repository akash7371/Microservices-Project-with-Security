package com.cg.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.FlightRatesResponse;
import com.cg.dto.SeatBooking;
import com.cg.entity.Flight;
import com.cg.exception.FlightException;
import com.cg.repository.FlightRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FlightServiceImpl implements FlightService {

	@Autowired
	private FlightRepo flightrepo;

	public String addflight(Flight flight) throws FlightException {

		log.info("Attempting to add flight with ID: {}", flight.getFlightId());

		Optional<Flight> byId = flightrepo.findById(flight.getFlightId());
		if (!byId.isPresent()) {
			flightrepo.save(flight);
			log.info("Flight with ID: {} added successfully", flight.getFlightId());
			return "flight added";
		} else {

			throw new FlightException("Flight already available for this id");
		}
	}

	public String deleteflight(int flightId) throws FlightException {
		log.info("Attempting to delete flight with ID: {}", flightId);

		Optional<Flight> byId = flightrepo.findById(flightId);
		if (byId.isPresent()) {
			flightrepo.deleteById(flightId);
			log.info("Flight with ID: {} deleted successfully", flightId);
			return "flight deleted";
		} else {
			throw new FlightException("Flight not present");
		}
	}

	public List<Flight> displayall(String from, String to, LocalDateTime date) throws FlightException {
		log.info("Fetching flights from: {} to: {} on date: {}", from, to, date);

		List<Flight> flights = flightrepo.findBySourceAndDestinationAndLocalDateTime(from, to, date);
		if (!flights.isEmpty()) {
			log.info("Found {} flights matching criteria", flights.size());
			return flights;
		} else {
			log.warn("No flights available from: {} to: {} on date: {}", from, to, date);
			throw new FlightException("No Flight available");
		}
	}

	public List<Flight> displayall() throws FlightException {

		log.info("Fetching all flights");

		List<Flight> all = flightrepo.findAll();
		if (!all.isEmpty()) {
			log.info("Found {} flights", all.size());
			return all;
		} else {
			log.warn("No flights found");
			throw new FlightException("No Flight found");
		}
	}

	@Override
	public String updateSeatDetails(List<SeatBooking> seatList, int id) throws FlightException {
		// TODO Auto-generated method stub
		log.info("Updating seat details for flight ID: {}", id);

		Optional<Flight> byId = flightrepo.findById(id);
		if (byId.isPresent()) {
			Flight flight = byId.get();
			int size = seatList.size();
			int ecoCount = 0;
			int busiCount = 0;
			for (SeatBooking sb : seatList) {
				if (sb.getSeatType().equalsIgnoreCase("economy"))
					ecoCount++;
				if (sb.getSeatType().equalsIgnoreCase("business"))
					busiCount++;
			}
			flight.getSeat().setTotalAvailableSeats(flight.getSeat().getTotalAvailableSeats() - size);
			flight.getSeat().setEconomyAvailable(flight.getSeat().getEconomyAvailable() - ecoCount);
			flight.getSeat().setBussinessAvailable(flight.getSeat().getBussinessAvailable() - busiCount);

			Flight save = flightrepo.save(flight);
			if (save != null) {
				log.info("Seat details updated successfully for flight ID: {}", id);
				return "Seat details updated successfully";
			} else {
				throw new FlightException("Some error occurred while updating seat details in flight");
			}
		} else {
			throw new FlightException("Flight not available for this Id");
		}

	}

	public Optional<FlightRatesResponse> getFlightRatesById(int flightId) throws FlightException {
		log.info("Fetching flight rates for flight ID: {}", flightId);

		Optional<Flight> flight = flightrepo.findById(flightId);
		if (flight.isPresent()) {
			Flight f = flight.get();
			FlightRatesResponse response = new FlightRatesResponse();
			response.setEconomyRate(f.getEconomyRate());
			response.setBusinessRate(f.getBusinessRate());
			log.info("Flight rates retrieved successfully for flight ID: {}", flightId);
			return Optional.of(response);
		} else {
			log.error("Flight with ID: {} not found for retrieving rates", flightId);
			throw new FlightException("Flight not available for this Id");
		}
	}

	@Override
	public Flight getFlightById(int flightId) throws FlightException {
		return flightrepo.findById(flightId)
				.orElseThrow(() -> new FlightException("Flight not found with ID: " + flightId));

	}

	@Override
	public Flight getFlightDateById(int id) throws FlightException {

		return flightrepo.findById(id)
	            .orElseThrow(() -> new FlightException("Flight not found with ID: " + id));
	}

}

package com.cg.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.FlightRatesResponse;
import com.cg.dto.SeatBooking;
import com.cg.entity.Flight;
import com.cg.exception.FlightException;
import com.cg.service.FlightService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/flight")
@Slf4j
public class FlightController {

	@Autowired
	private FlightService flightservice;

	@PostMapping("/addflight")
	@PreAuthorize("hasAuthority('admin')")
	public ResponseEntity<String> addflight(@RequestBody Flight flight) throws FlightException {

		log.info("- flight-service - Received request to add flight: {}", flight);

		String msg = flightservice.addflight(flight);
		log.info("- flight-service - {}", msg);
		return new ResponseEntity<String>(msg, HttpStatus.CREATED);

	}

	@GetMapping("/loadBySourceAndDestinationAndDate/{from}/{to}/{date}")
	@PreAuthorize("hasAuthority('user')")
	public ResponseEntity<List<Flight>> loadBySourceAndDestinationAndDate(@PathVariable String from,
			@PathVariable String to, @PathVariable String date) throws FlightException {
		log.info("- flight-service - Received request to load flights from: {} to: {} on date: {}", from, to, date);

		List<Flight> flights = flightservice.displayall(from, to, LocalDateTime.parse(date));
		if (flights.isEmpty()) {
			log.info("- flight-service - No flights found for the given criteria.");
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} else {
			log.info("- flight-service - Found {} flights for the given criteria.", flights.size());
			return new ResponseEntity<>(flights, HttpStatus.OK);
		}
	}

	@DeleteMapping("/deleteflight/{id}")
	@PreAuthorize("hasAuthority('admin')")
	public ResponseEntity<String> deleteflight(@PathVariable int id) throws FlightException {

		log.info("Received request to delete flight with ID: {}", id);

		String msg = flightservice.deleteflight(id);
		log.info("Flight deleted successfully with message");
		return new ResponseEntity<>(msg, HttpStatus.OK);

	}

	@GetMapping("/displayall")
	@PreAuthorize("hasAnyAuthority('admin','user')")
	public ResponseEntity<List<Flight>> displayall() throws FlightException {

		log.info("Received request to display all flights.");

		List<Flight> flightsList = flightservice.displayall();
		log.info("Retrieved {} flights.", flightsList.size());
		return new ResponseEntity<>(flightsList, HttpStatus.CREATED);
	}

	@PutMapping("/updateSeatDetails/{flightid}")
	@PreAuthorize("hasAnyAuthority('user', 'admin')")
	public ResponseEntity<String> updateSeatDetails(@RequestBody List<SeatBooking> seatList, @PathVariable int flightid)
			throws FlightException {

		log.info("Received request to update seat details for flight ID: {} with seatList: {}", flightid, seatList);

		String response = flightservice.updateSeatDetails(seatList, flightid);
		log.info("Seat details updated successfully for flight ID: {}", flightid);

		return ResponseEntity.ok(response);
	}

	@GetMapping("/rates/{flightId}")
	@PreAuthorize("hasAnyAuthority('user', 'admin')")
	public ResponseEntity<FlightRatesResponse> getFlightRates(@PathVariable int flightId) throws FlightException {
		log.info("Received request to get flight rates for flight ID: {}", flightId);

		Optional<FlightRatesResponse> flightRates = flightservice.getFlightRatesById(flightId);

		if (flightRates.isPresent()) {
			log.info("Flight rates retrieved successfully for flight ID: {}", flightId);
			return ResponseEntity.ok(flightRates.get());
		} else {
			log.warn("No flight rates found for flight ID: {}", flightId);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	@GetMapping("/getFlightById/{id}")
	@PreAuthorize("hasAnyAuthority('admin', 'user')")
	public ResponseEntity<Flight> getFlightById(@PathVariable int id) throws FlightException {
		log.info("Received request to get flight with ID: {}", id);

		Flight flight = flightservice.getFlightById(id);

		log.info("Retrieved flight with ID: {}", id);
		return new ResponseEntity<>(flight, HttpStatus.OK); // Return 200 OK if the flight is found
	}

	@GetMapping("/getFlightDateById/{id}")
	@PreAuthorize("hasAnyAuthority('admin', 'user')")
	public ResponseEntity<LocalDateTime> getFlightDateById(@PathVariable int id) throws FlightException {
		log.info("Received request to get flight date for flight ID: {}", id);

		// Call the service method to fetch the flight by its ID
		Flight flight = flightservice.getFlightDateById(id);

		LocalDateTime flightDate = flight.getLocalDateTime(); // Adjust the method to get date from the flight entity

		log.info("Retrieved flight date for flight ID: {}", id);
		return new ResponseEntity<>(flightDate, HttpStatus.OK); // Return 200 OK with the flight date
	}

	
	
	@GetMapping("/get")
	@PreAuthorize("hasAuthority('user')")
	public String getMessage() {
		return "flight-service";
	}
}

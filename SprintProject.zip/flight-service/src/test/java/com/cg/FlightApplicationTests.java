package com.cg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cg.controller.FlightController;
import com.cg.dto.FlightRatesResponse;
import com.cg.entity.Flight;
import com.cg.entity.Seat;
import com.cg.exception.FlightException;
import com.cg.exception.GlobalExceptionHandler;
import com.cg.service.FlightService;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class FlightApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FlightService flightService;

	@InjectMocks
	private FlightController flightController;

	private Flight flight;

	@InjectMocks
	private FlightRatesResponse flightRatesResponse;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(flightController)
				.setControllerAdvice(new GlobalExceptionHandler())
				.build();
		flight = new Flight(1, "Bangalore", "Delhi",LocalDateTime.now(), LocalTime.now(), LocalTime.now().plusHours(2),
				5000.0, 10000.0, new Seat(150, 100, 50, 150, 100, 50));
		 //org.joda.time.LocalDate localDate = new org.joda.time.LocalDate(LocalTime.now());
		// System.out.println(localDate+" Jaydeep");
	}


	@Test
	@WithMockUser(authorities = "admin")
	public void testAddFlight() throws Exception {
		when(flightService.addflight(flight)).thenReturn("Flight added successfully");

		mockMvc.perform(post("/flight/addflight").contentType(MediaType.APPLICATION_JSON).content(asJsonString(flight)))
				.andExpect(status().isCreated());
	}

	@Test
	@WithMockUser(authorities = "user")
	public void testLoadBySourceAndDestinationAndDate_FlightsFound() throws Exception {
		List<Flight> flights = List.of(flight);
		when(flightService.displayall("Bangalore", "Delhi", LocalDateTime.parse("2024-09-17T10:15:30")))
				.thenReturn(flights);

		mockMvc.perform(get("/flight/loadBySourceAndDestinationAndDate/Bangalore/Delhi/2024-09-17T10:15:30")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$.length()").value(flights.size()))
				.andExpect(jsonPath("$[0].flightId").value(flight.getFlightId()));
	}

	@Test
	@WithMockUser(authorities = "user")
	public void testLoadBySourceAndDestinationAndDate_NoFlightsFound() throws Exception {
		when(flightService.displayall("Bangalore", "Delhi", LocalDateTime.parse("2024-09-17T10:15:30")))
				.thenReturn(List.of());

		mockMvc.perform(get("/flight/loadBySourceAndDestinationAndDate/Bangalore/Delhi/2024-09-17T10:15:30")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNoContent());
	}

	@Test
	@WithMockUser(authorities = "admin")
	public void testDeleteFlight() throws Exception {
		int flightId = 1;
		when(flightService.deleteflight(flightId)).thenReturn("Flight deleted successfully");

		mockMvc.perform(delete("/flight/deleteflight/" + flightId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	@WithMockUser(authorities = { "admin", "user" })
	public void testDisplayAllFlights() throws Exception {
		List<Flight> flights = List.of(flight);
		when(flightService.displayall()).thenReturn(flights);

		mockMvc.perform(get("/flight/displayall").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated()).andExpect(jsonPath("$.length()").value(flights.size()))
				.andExpect(jsonPath("$[0].flightId").value(flight.getFlightId()));
	}

	
	@Test
    @WithMockUser(authorities = {"user", "admin"})
    public void testGetFlightRates_FlightRatesFound() throws Exception {
        int flightId = 1;
        when(flightService.getFlightRatesById(flightId)).thenReturn(Optional.of(flightRatesResponse));

        mockMvc.perform(get("/flight/rates/{flightId}", flightId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //.andExpect(jsonPath("$.flightId").value(flightId))
                .andExpect(jsonPath("$.economyRate").value(flightRatesResponse.getEconomyRate()))
                .andExpect(jsonPath("$.businessRate").value(flightRatesResponse.getBusinessRate()));
    }

    @Test
    @WithMockUser(authorities = {"user", "admin"})
    public void testGetFlightRates_FlightRatesNotFound() throws Exception {
        int flightId = 1;
        when(flightService.getFlightRatesById(flightId)).thenReturn(Optional.empty());

        mockMvc.perform(get("/flight/rates/{flightId}", flightId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(authorities = {"admin", "user"})
    public void testGetFlightById_FlightFound() throws Exception {
        int flightId = 1;
        when(flightService.getFlightById(flightId)).thenReturn(flight);

        mockMvc.perform(get("/flight/getFlightById/{id}", flightId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.flightId").value(flight.getFlightId()))
                .andExpect(jsonPath("$.source").value(flight.getSource()))
                .andExpect(jsonPath("$.destination").value(flight.getDestination()));
    }

    @Test
    @WithMockUser(authorities = {"admin", "user"})
    public void testGetFlightById_FlightNotFound() throws Exception {
        int flightId = 1;
        when(flightService.getFlightById(flightId)).thenThrow(new FlightException("Flight not found"));

        mockMvc.perform(get("/flight/getFlightById/{id}", flightId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isExpectationFailed())
                .andExpect(jsonPath("$").value("Flight not found"));
    }

    @Test
    @WithMockUser(authorities = {"admin", "user"})
    public void testGetFlightDateById_FlightFound() throws Exception {
        int flightId = 1;
        String flightDate = flight.getLocalDateTime().toString();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.nnnnnnnnn");
       // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS");
        LocalDateTime localDateTime = LocalDateTime.parse(flightDate, formatter);
        System.out.println(localDateTime +" Akash....");
        
        when(flightService.getFlightDateById(flightId)).thenReturn(flight);
        //System.out.println(flightDate);
        ResponseEntity<LocalDateTime> response = flightController.getFlightDateById(flightId);

//        mockMvc.perform(get("/flight/getFlightDateById/"+flightId)
//                .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$").value(localDateTime));
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(localDateTime, response.getBody());
        verify(flightService).getFlightDateById(flightId);
        
    }

    @Test
    @WithMockUser(authorities = {"admin", "user"})
    public void testGetFlightDateById_FlightNotFound() throws Exception {
        int flightId = 1;
        when(flightService.getFlightDateById(flightId)).thenThrow(new FlightException("Flight not found"));

        mockMvc.perform(get("/flight/getFlightDateById/{id}", flightId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isExpectationFailed())
                .andExpect(jsonPath("$").value("Flight not found"));
    }
	private static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper()
					.registerModule(new JavaTimeModule())
					.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
					.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}

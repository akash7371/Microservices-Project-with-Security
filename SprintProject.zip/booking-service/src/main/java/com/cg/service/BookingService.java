package com.cg.service;

import java.util.List;

import com.cg.entity.BookingDetails;
import com.cg.entity.SeatBooking;
import com.cg.exception.BookingException;

public interface BookingService {

	public BookingDetails createBooking(BookingDetails booking, String username, int flightId) throws BookingException, Exception;
	
	public BookingDetails addSeatBooking(List<SeatBooking> seatBookings, String bookingId) throws BookingException, Exception;
	
	public BookingDetails getBookingById(String bookingId) throws BookingException;
	
	//public int updateBookingStatus(String id, String status) throws BookingException;
	
	 public List<SeatBooking> getSeatDetailsByBookingId(String bookingId) throws BookingException;

	public String cancelBooking(String bookingId) throws BookingException, Exception;

}

package com.cg.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.dto.FlightRatesResponse;
import com.cg.entity.BookingDetails;
import com.cg.entity.SeatBooking;
import com.cg.exception.BookingException;
import com.cg.feign.FareFeign;
import com.cg.feign.FlightFeign;
import com.cg.repository.BookingRepo;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepo bookingRepo;

//	@Autowired
//	private SeatBookingRepo seatBookingRepo;

	@Autowired
	private FlightFeign flightFeign;

	@Autowired
	private FareFeign fareFeign;

	@Override
	public BookingDetails createBooking(BookingDetails booking, String username, int flightId)
			throws BookingException, Exception {

		Optional<BookingDetails> byId = bookingRepo.findById(booking.getBookingId());
		// checking for bookingId
		if (!byId.isPresent()) {
			List<BookingDetails> existingBookings = bookingRepo.findAll();

			for (SeatBooking newSeat : booking.getSeatBooking()) {
				// Check for duplicates within the same booking

				List<SeatBooking> seatBookings = booking.getSeatBooking();
				Map<Integer, Long> seatNumberCounts = seatBookings.stream()
						.collect(Collectors.groupingBy(SeatBooking::getSeatNumber, Collectors.counting()));

				Optional<Map.Entry<Integer, Long>> duplicateSeatEntry = seatNumberCounts.entrySet().stream()
						.filter(entry -> entry.getValue() > 1).findFirst();

				if (duplicateSeatEntry.isPresent()) {
					throw new BookingException(
							"Duplicate seat number " + duplicateSeatEntry.get().getKey() + " found in the booking.");
				}

				// Check for duplicates in other bookings
				boolean seatExistsInOtherBookings = existingBookings.stream().flatMap(b -> b.getSeatBooking().stream())
						.anyMatch(seat -> seat.getSeatNumber() == newSeat.getSeatNumber());

				if (seatExistsInOtherBookings) {
					throw new BookingException(
							"Seat number " + newSeat.getSeatNumber() + " already exists in another booking.");
				}
			}
			booking.setUsername(username);
			booking.setFlightId(flightId);
			ResponseEntity<FlightRatesResponse> flightRates = flightFeign.getFlightRates(flightId);
			FlightRatesResponse body = flightRates.getBody();
			double fare = fareFeign.calculateFare(body.getEconomyRate(), body.getBusinessRate(),
					booking.getSeatBooking());
			booking.setTotalFare(fare);
//		
			BookingDetails save = bookingRepo.save(booking);
			String updateSeatDetails = flightFeign.updateSeatDetails(save.getSeatBooking(), flightId);
			System.out.println(updateSeatDetails);
			return save;
		} else {

			throw new BookingException("Booking Id " + booking.getBookingId() + " already present");
		}
		// return null;
	}

	@Override
	public BookingDetails addSeatBooking(List<SeatBooking> seatBookings, String bookingId)
			throws BookingException, Exception {
//		
		
		for (SeatBooking newSeat : seatBookings) {
			// Check for duplicates within the same booking

			//List<SeatBooking> seatBookings = seatBookings;
			Map<Integer, Long> seatNumberCounts = seatBookings.stream()
					.collect(Collectors.groupingBy(SeatBooking::getSeatNumber, Collectors.counting()));

			Optional<Map.Entry<Integer, Long>> duplicateSeatEntry = seatNumberCounts.entrySet().stream()
					.filter(entry -> entry.getValue() > 1).findFirst();

			if (duplicateSeatEntry.isPresent()) {
				throw new BookingException(
						"Duplicate seat number " + duplicateSeatEntry.get().getKey() + " found in the booking.");
			}
		}
		Optional<BookingDetails> byId = bookingRepo.findById(bookingId);
		if (byId.isPresent()) {
			BookingDetails bookingDetails = byId.get();
			List<SeatBooking> seatBooking = bookingDetails.getSeatBooking();

			for (SeatBooking st1 : seatBookings) {
				for (SeatBooking st2 : seatBooking) {
					if (st1.getSeatNumber() == st2.getSeatNumber())
						throw new BookingException(
								"Seat number " + st1.getSeatNumber() + " already booked try another");
				}
			}
			seatBooking.addAll(seatBookings);
			bookingDetails.setSeatBooking(seatBooking);
			BookingDetails save = bookingRepo.save(bookingDetails);
			flightFeign.updateSeatDetails(seatBooking, bookingDetails.getFlightId());
			return save;

		} else
			throw new BookingException("Bookindid " + bookingId + " is not available");
	}

	@Override
	public BookingDetails getBookingById(String bookingId) throws BookingException {
		// TODO Auto-generated method stub
		Optional<BookingDetails> byId = bookingRepo.findById(bookingId);
		if (byId.isPresent())
			return byId.get();
		else
			throw new BookingException("Booking Id not available");
	}

	public List<SeatBooking> getSeatDetailsByBookingId(String bookingId) throws BookingException {

		Optional<BookingDetails> byId = bookingRepo.findById(bookingId);
		if (byId.isPresent()) {
			return byId.get().getSeatBooking();
		} else
			throw new BookingException("Booking Id not available");
	}

	@Override
	public String cancelBooking(String bookingId) throws BookingException, Exception {
		// Logic to cancel the booking
		// Example: Find the booking by ID, update its status, and save it

		BookingDetails booking = bookingRepo.findById(bookingId)
				.orElseThrow(() -> new BookingException("Booking not found"));

		if ("cancelled".equalsIgnoreCase(booking.getStatus())) {
			throw new BookingException("Booking is already cancelled");
		}
		ResponseEntity<LocalDateTime> flightDateById = flightFeign.getFlightDateById(booking.getFlightId());
		LocalDateTime flightDateTime = flightDateById.getBody();

		if (flightDateTime == null) {
			throw new BookingException("Flight date and time not found");
		}

		LocalDateTime currentDateTime = LocalDateTime.now();

		Duration sixHours = Duration.ofHours(6);

		Duration duration = Duration.between(currentDateTime, flightDateTime);
		if (duration.toHours() >= sixHours.toHours()) {
	        
	        booking.setStatus("cancelled");
	        bookingRepo.save(booking);
	        return "Booking cancelled successfully.";
	    } else {
	        
	        return "Cancellation not applicable. Cancellation can be done before 6 hours.";
	    }
	}

}

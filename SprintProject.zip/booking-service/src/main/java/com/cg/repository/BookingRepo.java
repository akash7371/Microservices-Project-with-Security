package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.entity.BookingDetails;
@Repository
public interface BookingRepo extends JpaRepository<BookingDetails, String>{

//	@Modifying
//    @Query("UPDATE BookingDetails b SET b.status = :status WHERE b.bookingId = :id")
//	int updateStatusByBookingId(@Param("status") String status,@Param("id") String id);

}

package com.cg.feign;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.dto.FlightRatesResponse;
import com.cg.entity.SeatBooking;


@Service
@FeignClient(name = "flight-service")
public interface FlightFeign {

	@GetMapping("/flight/rates/{flightId}")
	public ResponseEntity<FlightRatesResponse> getFlightRates(@PathVariable int flightId);

	@PutMapping("/flight/updateSeatDetails/{flightid}")
	public String updateSeatDetails(@RequestBody List<SeatBooking> seatList, @PathVariable int flightid)
			throws Exception;

	@GetMapping("/flight/getFlightDateById/{id}")
	public ResponseEntity<LocalDateTime> getFlightDateById(@PathVariable int id) throws Exception;
}

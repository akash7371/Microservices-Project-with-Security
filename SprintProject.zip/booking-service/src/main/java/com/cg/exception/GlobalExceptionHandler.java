package com.cg.exception;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	
	@Override
	  protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			  HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		
		log.error("-booking-service- Invalid date format: {}", ex.getMessage(), ex);
	        ExceptionResponse errorResponse = new ExceptionResponse(
	                ex.getMessage(),
	                "Invalid date format",
	                "The provided date format is incorrect. Please use 'yyyy-MM-dd'.",
	                LocalDateTime.now()
	        );
	        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	    }
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request){
				
		BindingResult result= ex.getBindingResult();
		List<String> list = result.getFieldErrors().stream().map(e->e.getField()+" : "+e.getDefaultMessage()).toList();
		 log.error("-booking-service- Validation failed: {}", list);
		ExceptionResponse res = new ExceptionResponse("Validation Failed", list.toString(), "404 Bad Request", LocalDateTime.now());
		return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@ExceptionHandler(BookingException.class)
	public ResponseEntity<Object> handleStudentException(BookingException ex){
		System.err.println(ex.getMessage());
		log.error("-booking-service- BookingException occurred: {}", ex.getMessage(), ex);
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.EXPECTATION_FAILED);
		
	}
	
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleDefaultException(Exception ex){
		//ex.printStackTrace();
		System.err.println(ex.getMessage());
		log.error("-booking-service- Unexcepted Exception occurred: {}", ex.getMessage(), ex);
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.EXPECTATION_FAILED);
		
	}
}

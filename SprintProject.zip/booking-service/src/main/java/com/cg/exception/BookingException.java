package com.cg.exception;

@SuppressWarnings("serial")
public class BookingException extends Exception {

	public BookingException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

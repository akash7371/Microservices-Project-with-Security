package com.cg.entity;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class SeatBooking {

    @Min(value = 1, message = "Seat number must be between 1 and 40")
    @Max(value = 40, message = "Seat number must be between 1 and 40")
    private int seatNumber;

    @NotBlank(message = "Seat type cannot be blank")
    private String seatType;

	

}

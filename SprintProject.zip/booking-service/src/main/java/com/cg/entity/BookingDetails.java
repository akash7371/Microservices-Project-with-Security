package com.cg.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingDetails {

	@Id
	@NotBlank(message = "Booking ID cannot be blank")
	private String bookingId;
	private int flightId;
	private String username;
	private double totalFare;
	
	@NotBlank(message = "Status cannot be blank")
	private String status;
	private LocalDateTime bookingDateTime;
	
	@ElementCollection
	private List<SeatBooking> seatBooking;
}

package com.cg.dto;

import lombok.Data;

@Data
public class FlightRatesResponse {

	private double economyRate;
    private double businessRate;
}

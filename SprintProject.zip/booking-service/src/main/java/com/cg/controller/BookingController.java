package com.cg.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.BookingDetails;
import com.cg.entity.SeatBooking;
import com.cg.exception.BookingException;
import com.cg.service.BookingService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@PostMapping("/createBooking/{flightId}")
	@PreAuthorize("hasAuthority('user')")
	ResponseEntity<BookingDetails> createBooking(Principal principal, @Valid @RequestBody BookingDetails details,
			@PathVariable int flightId) throws Exception {
		String name = principal.getName();
		log.info("-booking-service- Creating booking with flightId: {}", flightId);
		BookingDetails bookingDetails = bookingService.createBooking(details, name, flightId);
		log.info("-booking-service- Booking created:");
		return new ResponseEntity<>(bookingDetails, HttpStatus.CREATED);

	}

	@PostMapping("/addSeatBooking/{bookingId}")
	@PreAuthorize("hasAuthority('user')")
	public ResponseEntity<BookingDetails> addSeatBooking(@Valid @RequestBody List<SeatBooking> seatBookings,
			@PathVariable String bookingId) throws Exception {
		log.info("-booking-service- Adding seat bookings to bookingId: {}", bookingId);
		BookingDetails updatedBooking = bookingService.addSeatBooking(seatBookings, bookingId);
		log.info("-booking-service- Seat bookings added");
		return ResponseEntity.ok(updatedBooking);
	}

	@GetMapping("/getBookingById/{bookingId}")
	@PreAuthorize("hasAnyAuthority('user')")
	public ResponseEntity<BookingDetails> getBookingById(@PathVariable String bookingId) throws BookingException {
		log.info("-booking-service- Fetching booking details for bookingId: {}", bookingId);
		BookingDetails booking = bookingService.getBookingById(bookingId);
		log.info("-booking-service- Fetched booking details");
		return ResponseEntity.ok(booking);

	}

	@GetMapping("/getSeatDetails/{bookingId}")
	@PreAuthorize("hasAuthority('user')")
	public ResponseEntity<List<SeatBooking>> getSeatDetailsByBookingId(@PathVariable String bookingId)
			throws BookingException {

		log.info("-booking-service- Fetching seat details for bookingId: {}", bookingId);
		List<SeatBooking> seatDetails = bookingService.getSeatDetailsByBookingId(bookingId);
		log.info("-booking-service- Fetched seat details");
		return ResponseEntity.ok(seatDetails);
	}

	@PutMapping("/cancelBooking/{bookingId}")
	@PreAuthorize("hasAnyAuthority('user','admin')")
	public ResponseEntity<String> cancelBooking(@PathVariable String bookingId) throws Exception {
		log.info("-booking-service- Cancelling booking with bookingId: {}", bookingId);
		String cancelledBooking = bookingService.cancelBooking(bookingId);
		log.info("-booking-service- Booking cancelled");
		return ResponseEntity.ok(cancelledBooking);
	}

	@GetMapping("/get")
	@PreAuthorize("hasAuthority('user')")
	public String getMessage() {
		return "booking service";
	}

}

package com.cg;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.cg.entity.BookingDetails;
import com.cg.entity.SeatBooking;
import com.cg.service.BookingService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class BookingServiceApplicationTests {

	@MockBean
	private BookingService bookingService;

	@Autowired(required = true)
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@BeforeEach
	public void setup() {

		objectMapper.registerModule(new JavaTimeModule());
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	@Test
	@WithMockUser(username = "akash", authorities = { "user" })
	public void testCreateBooking() throws JsonProcessingException, Exception {

		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setBookingId("12345");
		bookingDetails.setFlightId(139);
		bookingDetails.setUsername("akash");
		bookingDetails.setTotalFare(100.0);
		bookingDetails.setStatus("CONFIRMED");
		bookingDetails.setBookingDateTime(LocalDateTime.now());
		bookingDetails.setSeatBooking(List.of(new SeatBooking(8, "economy"), new SeatBooking(10, "business")));

		when(bookingService.createBooking(any(BookingDetails.class), anyString(), anyInt())).thenReturn(bookingDetails);

		mockMvc.perform(post("/createBooking/139")
				.contentType(MediaType.APPLICATION_JSON)

				.content(objectMapper.writeValueAsString(bookingDetails)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.username").value("akash"));
	}

	@Test
	@WithMockUser(username = "akash", authorities = { "user" })
	public void testAddSeatBooking() throws JsonProcessingException, Exception {
		String bookingId = "12345";
		List<SeatBooking> seatBookings = List.of(new SeatBooking(1, "economy"), new SeatBooking(2, "business"));
		BookingDetails updatedBooking = new BookingDetails();
		updatedBooking.setBookingId(bookingId);
		updatedBooking.setSeatBooking(seatBookings);

		when(bookingService.addSeatBooking(anyList(), eq(bookingId))).thenReturn(updatedBooking);

		mockMvc.perform(post("/addSeatBooking/" + bookingId).contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(seatBookings))).andExpect(status().isOk())
				.andExpect(jsonPath("$.bookingId").value(bookingId))
				.andExpect(jsonPath("$.seatBooking[0].seatType").value("economy"))
				.andExpect(jsonPath("$.seatBooking[1].seatType").value("business"));

		verify(bookingService, times(1)).addSeatBooking(anyList(), eq(bookingId));
	}

	@Test
	@WithMockUser(username = "akash", authorities = { "user", "admin" })
	public void testGetBookingById() throws Exception {
		String bookingId = "12345";
		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setBookingId(bookingId);
		bookingDetails.setFlightId(1);
		bookingDetails.setUsername("akash");
		bookingDetails.setTotalFare(100.0);
		bookingDetails.setStatus("CONFIRMED");
		bookingDetails.setBookingDateTime(LocalDateTime.now());
		bookingDetails.setSeatBooking(List.of(new SeatBooking(1, "economy"), new SeatBooking(2, "business")));

		when(bookingService.getBookingById(bookingId)).thenReturn(bookingDetails);

		mockMvc.perform(get("/getBookingById/" + bookingId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.bookingId").value(bookingId))
				.andExpect(jsonPath("$.username").value("akash"))
				.andExpect(jsonPath("$.seatBooking[0].seatType").value("economy"))
				.andExpect(jsonPath("$.seatBooking[1].seatType").value("business"));

		verify(bookingService, times(1)).getBookingById(bookingId);
	}
	

    @Test
    @WithMockUser(username = "akash", authorities = { "user" })
    public void testGetSeatDetailsByBookingId() throws Exception {
        String bookingId = "12345";
        List<SeatBooking> seatBookings = List.of(new SeatBooking(1, "economy"), new SeatBooking(2, "business"));

        when(bookingService.getSeatDetailsByBookingId(anyString())).thenReturn(seatBookings);

        mockMvc.perform(get("/getSeatDetails/" + bookingId).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].seatType").value("economy"))
                .andExpect(jsonPath("$[1].seatType").value("business"));

        verify(bookingService, times(1)).getSeatDetailsByBookingId(bookingId);
    }
    
    @Test
    @WithMockUser(username = "akash", authorities = { "user", "admin" })
    public void testCancelBooking() throws Exception {
        String bookingId = "12345";
        String cancelledMessage = "Booking cancelled successfully";

        when(bookingService.cancelBooking(anyString())).thenReturn(cancelledMessage);

        mockMvc.perform(put("/cancelBooking/" + bookingId).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(bookingService, times(1)).cancelBooking(bookingId);
    }

}

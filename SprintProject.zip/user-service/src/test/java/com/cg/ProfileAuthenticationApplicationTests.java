package com.cg;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.cg.controller.Controller;
import com.cg.dto.AuthRequest;
import com.cg.dto.ResponseDto;
import com.cg.entity.Profile;
import com.cg.repository.UserProfileRepository;
import com.cg.service.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class ProfileAuthenticationApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AuthService authService;

	@MockBean
	private UserProfileRepository userRepo;

	@MockBean
	private AuthenticationManager authenticationManager;

	@MockBean
	private Authentication authentication;
	@InjectMocks
	private Controller controller;

	@Autowired
	private ObjectMapper objectMapper;

	// Test case for successful user registration

	@Test
	public void testRegisterUserSuccess() throws Exception {
		Profile user = new Profile();
		user.setUsername("akash");
		user.setPassword("akash@1223");
		user.setEmailId("akjsskb@gmail.com");
		user.setGender("Male");
		user.setMobileNumber("9420209414");
		user.setRole("user");

		when(authService.saveUser(user)).thenReturn("User registered successfully");

		mockMvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isOk()).andExpect(jsonPath("$").value("User registered successfully"));
	}

	// Test case for failed user registration
	@Test
	public void testRegisterUserFailure() throws Exception {
		Profile user = new Profile();
		user.setUsername("akash");
		user.setPassword("akash@1223");
		user.setEmailId("akjsskb@gmail.com");
		user.setGender("Male");
		user.setMobileNumber("9420209414");
		user.setRole("user");
		when(authService.saveUser(user)).thenThrow(new RuntimeException("Registration failed"));

		mockMvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(asJsonString(user)))
				.andExpect(status().isInternalServerError());
	}

	// Test case for successful login
	@Test
	public void testLoginSuccess() throws Exception {
		AuthRequest authRequest = new AuthRequest();
		authRequest.setUsername("testuser");
		authRequest.setPassword("akash@1223");

		Profile user = new Profile();
		user.setUsername("testuser");
		user.setPassword("akash@1223");
		user.setEmailId("akjsskb@gmail.com");
		user.setGender("Male");
		user.setMobileNumber("9420209414");
		user.setRole("user");

		Authentication mockAuthentication = mock(Authentication.class);
		when(mockAuthentication.isAuthenticated()).thenReturn(true);
		authentication = new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword());
		when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
				.thenReturn(mockAuthentication);
		when(authService.generateToken(authRequest.getUsername())).thenReturn("test-token");

		when(userRepo.findUserIdByUsername(authRequest.getUsername())).thenReturn(java.util.Optional.of(user));

		ResponseDto responseDto = new ResponseDto();
		responseDto.setToken("mockToken");
		responseDto.setRole("user");

		mockMvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(asJsonString(authRequest)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.token").value("test-token"))
				.andExpect(jsonPath("$.role").value("user"));
	}

	// Test case for failed login
	@Test
	public void testLoginFailure() throws Exception {
		AuthRequest authRequest = new AuthRequest();
		authRequest.setUsername("testuser");
		authRequest.setPassword("wrongpassword");

		when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
				.thenThrow(new RuntimeException("invalid access"));

		mockMvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(asJsonString(authRequest)))
				.andExpect(status().isInternalServerError());
	}

	// Test case for successful token validation
	@Test
	public void testValidateTokenSuccess() throws Exception {
		String token = "valid-token";

		mockMvc.perform(get("/auth/validate").param("token", token)).andExpect(status().isOk())
				.andExpect(jsonPath("$").value("Token is valid"));
	}

	//Test case for failed token validation
	@Test
	public void testValidateTokenFailure() throws Exception {
		String token = "invalid-token";

		doThrow(new RuntimeException("Invalid token")).when(authService).validateToken(token);

		mockMvc.perform(get("/auth/validate").param("token", token)).andExpect(status().isInternalServerError());
	}

	// Helper method to convert objects to JSON strings
	private String asJsonString(final Object obj) {
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}

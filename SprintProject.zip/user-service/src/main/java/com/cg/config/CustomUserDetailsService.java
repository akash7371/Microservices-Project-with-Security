package com.cg.config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.cg.entity.Profile;

import com.cg.repository.UserProfileRepository;

import lombok.extern.slf4j.Slf4j;

//import com.cg.entity.UserCredential;
//import com.cg.repository.UserCredentialRepository;
@Component
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

	 @Autowired
	    private UserProfileRepository repository;

	    @Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	    	
	    	log.info("Loading user details for username: {}", username);
	        Optional<Profile> credential = repository.findUserIdByUsername(username);
	        System.out.println(credential.isPresent());
	        log.info("User found with username: {}", username);
	        return credential.map(CustomUserDetails::new).orElseThrow(() -> new UsernameNotFoundException("user not found with name :" + username));
	    }
}

package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CheckInRequestBody;
import com.cg.dto.CheckInResponse;
import com.cg.service.CheckInService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CheckInController {

	@Autowired
	private CheckInService checkInService;

	@PostMapping("/checkIn")
	@PreAuthorize("hasAuthority('admin')")
	public ResponseEntity<CheckInResponse> createCheckIn(@Valid @RequestBody CheckInRequestBody requestBody) throws Exception {

		log.info("- flight-checkin - Received check-in request with details: {}", requestBody);

		CheckInResponse response = checkInService.createCheckIn(requestBody);

		log.info("- flight-checkin - Check-in response got from service layer");

		return ResponseEntity.ok(response);

	}

	@GetMapping("/get")
	@PreAuthorize("hasAuthority('admin')")
	public String getMessage() {
		return "search-service";
	}
}

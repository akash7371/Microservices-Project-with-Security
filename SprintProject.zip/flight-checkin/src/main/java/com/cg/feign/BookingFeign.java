package com.cg.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.dto.BookingDetails;

@Service
@FeignClient(name = "booking-service")
public interface BookingFeign {

	@GetMapping("/getBookingById/{bookingId}")
    public ResponseEntity<BookingDetails> getBookingById(@PathVariable String bookingId) throws Exception;
}

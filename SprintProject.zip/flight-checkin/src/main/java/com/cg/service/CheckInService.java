package com.cg.service;

import com.cg.dto.CheckInRequestBody;
import com.cg.dto.CheckInResponse;
import com.cg.exception.CheckInException;

public interface CheckInService {

	CheckInResponse createCheckIn(CheckInRequestBody requestBody) throws CheckInException,Exception;

}

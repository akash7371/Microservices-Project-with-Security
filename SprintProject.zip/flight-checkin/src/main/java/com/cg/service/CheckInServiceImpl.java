package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.dto.BookingDetails;
import com.cg.dto.CheckInRequestBody;
import com.cg.dto.CheckInResponse;
import com.cg.entity.CheckIn;
import com.cg.exception.CheckInException;
import com.cg.feign.BookingFeign;
import com.cg.repository.CheckInRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CheckInServiceImpl implements CheckInService {

	/* abcdefghijklmnopqrstuvwxyz */
	@Autowired
	private CheckInRepository checkInRepository;

	@Autowired
	private BookingFeign bookingFeign;

	@Override
	public CheckInResponse createCheckIn(CheckInRequestBody req) throws CheckInException, Exception {
		// TODO Auto-generated method stub

		log.info("- flight-checkin - Attempting to create check-in with request: ");
		CheckIn byId = checkInRepository.findByBookingId(req.getBookingId());

		if (byId == null) {

			log.info("- flight-checkin - Calling external service to get booking details");
			ResponseEntity<BookingDetails> bookingById = bookingFeign.getBookingById(req.getBookingId());
			BookingDetails booking = bookingById.getBody();
			log.info("- flight-checkin - Retrieved booking details");

			CheckIn checkIn = new CheckIn();
			checkIn.setCheckInId(req.getCheckInId());
			checkIn.setCheckInStatus(req.getCheckInStatus());
			checkIn.setBookingId(req.getBookingId());
			checkIn.setUsername(booking.getUsername());
			checkIn.setDateTime(req.getDateTime());
			checkIn.setFlightId(booking.getFlightId());
			checkIn.setBaggageWeight(req.getBaggageWeight());

			CheckIn save = checkInRepository.save(checkIn);

			log.info("- flight-checkin - Check-in saved successfully");
			CheckInResponse checkInResponse = CheckInResponse.builder().checkInId(save.getCheckInId())
					.checkInStatus(save.getCheckInStatus()).bookingId(save.getBookingId()).flightId(save.getFlightId())
					.username(save.getUsername()).dateTime(save.getDateTime()).baggageWeight(save.getBaggageWeight())
					.seatbooking(booking.getSeatBooking()).build();

			log.info("- flight-checkin - Check-in response created");
			return checkInResponse;
		} else
			throw new CheckInException("Checkin already done for this booking id");
	}

}

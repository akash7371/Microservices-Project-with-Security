package com.cg.exception;

public class CheckInException extends Exception {

	public CheckInException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

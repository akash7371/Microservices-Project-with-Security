package com.cg.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckIn {
	
	@Id
	private int checkInId;
	private String checkInStatus;
	private String bookingId;
	private int flightId;
	private String username;
	private LocalDateTime dateTime;
	private double baggageWeight;
	
	
	
}

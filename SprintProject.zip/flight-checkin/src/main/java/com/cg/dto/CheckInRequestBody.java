package com.cg.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckInRequestBody {

	@NotNull(message = "Check-in ID cannot be null")
    private Integer checkInId;

    @NotBlank(message = "Check-in status cannot be blank")
    private String checkInStatus;

    @NotBlank(message = "Booking ID cannot be blank")
    private String bookingId;

    @NotNull(message = "Date and time cannot be null")
    private LocalDateTime dateTime;

    @DecimalMin(value = "0.0", inclusive = true, message = "Baggage weight must be zero or positive")
    private double baggageWeight;
}

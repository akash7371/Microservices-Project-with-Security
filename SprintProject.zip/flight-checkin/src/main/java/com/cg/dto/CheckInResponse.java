package com.cg.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CheckInResponse {

	private int checkInId;
	private String checkInStatus;
	private String bookingId;
	private int flightId;
	private String username;
	private LocalDateTime dateTime;
	private double baggageWeight;
	
	List<SeatBooking> seatbooking;
}

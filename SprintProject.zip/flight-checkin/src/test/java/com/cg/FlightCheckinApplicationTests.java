package com.cg;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cg.controller.CheckInController;
import com.cg.dto.CheckInRequestBody;
import com.cg.dto.CheckInResponse;
import com.cg.dto.SeatBooking;
import com.cg.service.CheckInService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class FlightCheckinApplicationTests {

	
	 @Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private CheckInService checkInService;
	    @InjectMocks
	    private CheckInController checkInController;
	    
	  @Autowired
	    private ObjectMapper objectMapper;

	    @BeforeEach
	    public void setup() {
	        MockitoAnnotations.openMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(checkInController).build();
	    }

	    @Test
	    @WithMockUser(authorities = "admin")
	    public void testCreateCheckIn() throws Exception {
	        CheckInRequestBody requestBody = new CheckInRequestBody(1, "CheckedIn", "B123", LocalDateTime.now(), 15.0);
	        CheckInResponse response = CheckInResponse.builder()
	                .checkInId(1)
	                .checkInStatus("CheckedIn")
	                .bookingId("B123")
	                .flightId(101)
	                .username("user1")
	                .dateTime(LocalDateTime.now())
	                .baggageWeight(15.0)
	                .seatbooking(Arrays.asList(new SeatBooking(1, "Economy"), new SeatBooking(2, "Business")))
	                .build();

	        when(checkInService.createCheckIn(requestBody)).thenReturn(response);

	        mockMvc.perform(post("/checkIn")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(objectMapper.writeValueAsString(requestBody)))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.checkInId").value(1))
	                .andExpect(jsonPath("$.checkInStatus").value("CheckedIn"))
	                .andExpect(jsonPath("$.bookingId").value("B123"))
	                .andExpect(jsonPath("$.flightId").value(101))
	                .andExpect(jsonPath("$.username").value("user1"))
	                .andExpect(jsonPath("$.dateTime").exists())
	                .andExpect(jsonPath("$.baggageWeight").value(15.0))
	                .andExpect(jsonPath("$.seatbooking[0].seatNumber").value(1))
	                .andExpect(jsonPath("$.seatbooking[0].seatType").value("Economy"))
	                .andExpect(jsonPath("$.seatbooking[1].seatNumber").value(2))
	                .andExpect(jsonPath("$.seatbooking[1].seatType").value("Business"));
	    }

}

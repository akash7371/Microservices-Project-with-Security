package com.cg.exception;

import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class CustomizedExceptionHandler {
	
	
	@ExceptionHandler(GatewayException.class)
	public final ResponseEntity<Object> handleAllExceptions(GatewayException ex, WebRequest request) {
		System.out.println("exception ...");
		//ex.printStackTrace();
		//AbstractErrorWebExceptionHandler
		System.err.println(ex.getMessage());
		log.error(ex.getMessage());
	    ExceptionResponse exceptionResponse =new ExceptionResponse(ex.getMessage(), request.getDescription(false),
	    		"500 Internal Server Error", LocalDateTime.now());
	    return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		System.out.println("exception ...");
		//ex.printStackTrace();
		System.err.println(ex.getMessage());
		log.error(ex.getMessage());
	    ExceptionResponse exceptionResponse =new ExceptionResponse(ex.getMessage(), request.getDescription(false),
	    		"500 Internal Server Error", LocalDateTime.now());
	    return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}

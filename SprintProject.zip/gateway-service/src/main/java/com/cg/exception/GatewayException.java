package com.cg.exception;

@SuppressWarnings("serial")
public class GatewayException extends Exception {

	public GatewayException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

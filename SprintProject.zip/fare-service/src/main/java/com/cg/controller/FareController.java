package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.SeatBooking;
import com.cg.service.FareService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class FareController {

	@Autowired
	private FareService fareService;

	@PostMapping("/calculateFare/{ecoPrice}/{busiPrice}")
	@PreAuthorize("hasAuthority('user')")
	public double calculateFare(@PathVariable double ecoPrice, @PathVariable double busiPrice,
			@RequestBody List<SeatBooking> seatdetails) {

		log.info("- fare-service - Calculating fare with ecoPrice: {}, busiPrice: {}, seatdetails: {}", ecoPrice,
				busiPrice, seatdetails);

		// Calling the service method to calculate the fare
		double fare = fareService.calculateTotalFare(ecoPrice, busiPrice, seatdetails);
		// Log the calculated fare
		log.info("- fare-service - Calculated fare: {}", fare);
		return fare;

	}
}

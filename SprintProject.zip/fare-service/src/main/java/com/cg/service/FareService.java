package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.dto.SeatBooking;

@Service
public interface FareService {

	double calculateTotalFare(double ecoPrice, double busiPrice, List<SeatBooking> seatdetails) ;

}

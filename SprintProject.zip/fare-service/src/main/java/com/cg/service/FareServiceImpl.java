package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.dto.SeatBooking;

@Service
public class FareServiceImpl implements FareService {

	@Override
	public double calculateTotalFare(double ecoPrice, double busiPrice, List<SeatBooking> seatDetails) {
		// TODO Auto-generated method stub
		double totalFare = 0.0;

        for (SeatBooking seat : seatDetails) {
            String seatType = seat.getSeatType().toLowerCase();

            if ("economy".equals(seatType)) {
                totalFare += ecoPrice ;
            } else if ("business".equals(seatType)) {
                totalFare += busiPrice;
            }
        }

        return totalFare;
		//return 0;
	}

}

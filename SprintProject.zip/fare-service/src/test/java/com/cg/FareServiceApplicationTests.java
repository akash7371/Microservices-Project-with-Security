package com.cg;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cg.controller.FareController;
import com.cg.dto.SeatBooking;
import com.cg.service.FareService;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class FareServiceApplicationTests {

	@Autowired
    private MockMvc mockMvc;

    @MockBean
    private FareService fareService;

    @InjectMocks
    private FareController fareController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(fareController).build();
    }

    @Test
    @WithMockUser(authorities = "user")
    public void testCalculateFare() throws Exception {
        double ecoPrice = 100.0;
        double busiPrice = 200.0;
        List<SeatBooking> seatdetails = Arrays.asList(new SeatBooking(1, "Economy"), new SeatBooking(2, "Business"));

        when(fareService.calculateTotalFare(ecoPrice, busiPrice, seatdetails)).thenReturn(500.0);

        mockMvc.perform(post("/calculateFare/{ecoPrice}/{busiPrice}", ecoPrice, busiPrice)
                .contentType("application/json")
                .content("[{\"seatNumber\":1,\"seatType\":\"Economy\"},{\"seatNumber\":2,\"seatType\":\"Business\"}]"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value(500.0));
    }

    @Test
    @WithMockUser( authorities = "admin")
    public void testCalculateFareUnauthorized() throws Exception {
        double ecoPrice = 100.0;
        double busiPrice = 200.0;
        List<SeatBooking> seatdetails = Arrays.asList(new SeatBooking(1, "Economy"), new SeatBooking(2, "Business"));

        mockMvc.perform(post("/calculateFare/{ecoPrice}/{busiPrice}", ecoPrice, busiPrice)
                .contentType("application/json")
                .content("[{\"seatNumber\":1,\"seatType\":\"Economy\"},{\"seatNumber\":2,\"seatType\":\"Business\"}]"))
                .andExpect(status().isForbidden());
    }
    
//    @Test
//    @WithMockUser(authorities = "user")
//    public void testCalculateFareFailure() throws Exception {
//        double ecoPrice = 100.0;
//        double busiPrice = 200.0;
//        List<SeatBooking> seatdetails = Arrays.asList(new SeatBooking(1, "Economy"), new SeatBooking(2, "Business"));
//
//        when(fareService.calculateTotalFare(ecoPrice, busiPrice, seatdetails)).thenThrow(new RuntimeException("Calculation error"));
//
//        mockMvc.perform(post("/calculateFare/{ecoPrice}/{busiPrice}", ecoPrice, busiPrice)
//                .contentType("application/json")
//                .content("[{\"seatNumber\":1,\"seatType\":\"Economy\"},{\"seatNumber\":2,\"seatType\":\"Business\"}]"))
//                .andExpect(status().isInternalServerError());
//    }

}
